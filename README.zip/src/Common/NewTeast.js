import React from 'react'; 
import {ContractDetails} from '../Contracts/ContractDetails';

const func = async () => {
    return ContractDetails;
}
export default func;